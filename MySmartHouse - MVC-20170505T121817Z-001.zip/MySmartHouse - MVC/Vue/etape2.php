<?php
    $entete = entete("Mon site / Étape 2");
    $menu = menu("etape2");
    $contenu = "<h2>Contenu de l'étape 2</h2>";
    $pied = pied();

    include 'gabarit.php';
?>
