<?php
    $entete = entete("Mon site / Accueil");
    $menu = menu("accueil");
    $contenu = "<h2>Contenu de l'accueil</h2>";
    $pied = pied();

    include 'gabarit.php';
?>