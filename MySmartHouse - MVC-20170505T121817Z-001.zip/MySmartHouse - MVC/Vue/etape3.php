<?php
    $entete = entete("Mon site / Étape 3");
    $menu = menu("etape3");
    $contenu = "<h2>Contenu de l'étape 3</h2>";
    $pied = pied();

    include 'gabarit.php';
?>
